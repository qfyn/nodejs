import storeSystem from 'hi-fas-utils/src/storeSystem'

export default storeSystem
