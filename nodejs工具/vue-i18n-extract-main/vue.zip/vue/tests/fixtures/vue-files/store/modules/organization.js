// 平台管理
// import { uuid } from '@/utils/index'

const getDefaultState = () => {
  return {
    organizationTree: [], // 组织平台树数据
    selectNodeTree: null, // 选中组织树中的数据
    selectNodeData: null, // 用户点击平台，项目，标段的数据
    departmentList: [] // 部门列表
  }
}

// 格式化组织树
// const fomateTreeItem = function(item) {
//   item.guid = uuid()
//   // item.label = item.name
//   switch (item.layer) {
//     case 0: { // 组织
//       item.icon = 'folder'
//       item.bold = 'bold'
//       break
//     }
//     case 1: { // 平台
//       item.icon = 'folder'
//       break
//     }
//     case 2: { // 项目
//       break
//     }
//     case 3: { // 标段
//       break
//     }
//   }
//   if (item.children && item.children.length > 0) {
//     item.children.forEach(temp => { fomateTreeItem(temp) })
//   }
// }
// 插入树
// const insertTreeItem = function (treeData, parentGuid, item) {
//   if (!Array.isArray(treeData) || treeData.length === 0) return
//   for (let index = 0; index < treeData.length; index++) {
//     const element = treeData[index];
//     if (element.guid === parentGuid) {
//       if (!element.children) element.children = []
//       element.children.push(item)
//       break
//     }
//     insertTreeItem(element.children, parentGuid, item)
//   }
// }

const stateModul = getDefaultState()

const mutations = {
  // 更新组织树
  SET_ORGTREE: (state, treeData) => {
    // 格式化数据
    // treeData.forEach(ele => { fomateTreeItem(ele) })
    // // 对比更新
    // const merge = function(oldList, newList) {
    //   if (!Array.isArray(newList)) return
    //   if (!Array.isArray(oldList)) {
    //     oldList = newList
    //     return
    //   }
    //   if (oldList.length !== newList.length) {
    //     // 删除
    //     for (let index = oldList.length - 1; index >= 0; index--) {
    //       if (!newList.find(item => { return item.id === oldList[index].id })) {
    //         oldList.splice(index, 1)
    //       }
    //     }
    //     // 新增
    //     for (let index = 0; index < newList.length; index++) {
    //       if (!oldList.find(item => { return item.id === newList[index].id })) {
    //         oldList.splice(index, 0, newList[index])
    //       }
    //     }
    //   } else {
    //     for (let index = 0; index < oldList.length; index++) {
    //       const newItem = newList.find(item => { return item.id === oldList[index].id })
    //       // 修改
    //       oldList[index] = newItem
    //       // if (oldList[index].name !== newItem.name) {
    //       //   oldList[index].name = newItem.name
    //       //   oldList[index].label = newItem.label
    //       // }
    //       merge(oldList[index].children, newItem.children)
    //     }
    //   }
    // }
    // merge(state.organizationTree, treeData)
    state.organizationTree = treeData
  },
  // 更新选中树id
  SET_SELECTNODETREE: (state, val) => {
    state.selectNodeTree = val
  },
  // 更新点击树的id
  SET_SELECTNODEDATA: (state, val) => {
    state.selectNodeData = val
  },
  // 部门列表
  SET_DEPARTMENTLIST: (state, departmentList) => {
    state.departmentList = departmentList
  }

  // // 新增平台树
  // ADD_PLATFORMTREE: (state, parentGuid, val) => {
  //   val.layer = 1
  //   val.name = val.platformName
  //   insertTreeItem(state.organizationTree, parentGuid, fomateTreeItem(val))
  // },
  // // 新增项目树
  // ADD_PROJECTTREE: (state, parentGuid, val) => {
  //   val.layer = 2
  //   val.name = val.projectName
  //   insertTreeItem(state.organizationTree, parentGuid, fomateTreeItem(val))
  // },
  // // 新增标段树
  // ADD_SECTIONTREE: (state, parentGuid, val) => {
  //   val.layer = 3
  //   val.name = val.sectionName
  //   insertTreeItem(state.organizationTree, parentGuid, fomateTreeItem(val))
  // },
  // // 根据节点id删除节点
  // DELETE_ORGTREENODE: (state, guid) => {
  //   const deleteNode = function(list) {
  //     if (!Array.isArray(list)) return
  //     for (let index = 0; index < list.length; index++) {
  //       const element = list[index];
  //       if (element.guid === guid) {
  //         list.splice(index, 1)
  //         break
  //       }
  //       deleteNode(element.children)
  //     }
  //   }
  //   deleteNode(state.organizationTree)
  // },
}

const actions = {
  // 获取组织树
  getOrgTree({ commit, state }, param) {
    return new Promise((resolve, reject) => {
      tools.api.organization.queryOrgTree().then(res => {
        if (res?.data) {
          commit('SET_ORGTREE', res.data)
          const departments = handelDepartment(res.data) || []
          handelDepartment_(departments)
          commit('SET_DEPARTMENTLIST', departments)
          resolve()
        } else {
          reject()
        }
      })
    })
  }
}

function handelDepartment_(dataAll) {
  dataAll.forEach(currentItem => {
    handleAddOrgName(dataAll, currentItem, currentItem)
    currentItem.orgName = `${currentItem.orgName.length ? '(' + currentItem.orgName.join('/') + ')' : ''}`
  })
}

function handleAddOrgName(dataAll, currentItem, parentItem) {
  dataAll.find(item => {
    if (item.id === parentItem.parentId) {
      currentItem.orgName.unshift(item.deptSimpleName)
      if (item.parentId) {
        handleAddOrgName(dataAll, currentItem, item)
      }
    }
  })
}

function handelDepartment(data, list = []) {
  data.forEach(item => {
    item.orgName = []
    list.push(item)
    if (item.children) handelDepartment(item.children, list)
  })
  return list
}

export default {
  namespaced: true,
  state: stateModul,
  mutations,
  actions
}

