import { asyncRoute } from '@/router/asyncRoute'
import { constantRoutes } from '@/router'
import Layout from '@/layout'
import { compositeRoutes } from 'hi-fas-utils/src/permission'
import i18n from '@/lang'
const stateModal = {
  routes: [],
  addRoutes: [],
  systemTitle: () => { return i18n.t('route.AccountCenter') }
}

const mutations = {
  SET_ROUTES: (state, routes) => {
    state.addRoutes = routes
    state.routes = constantRoutes.concat(routes)
  },
  SET_SYSTEMTITLE: (state, systemTitle) => {
    state.systemTitle = () => { return i18n.t('route.AccountCenter') }
  }
}

const actions = {
  generateRoutes({ commit }, routesData) {
    return new Promise(resolve => {
      const accessedRoutes = compositeRoutes(asyncRoute, routesData, Layout)
      const defaultPage = accessedRoutes.find(item => item.path === '/')
      if (!defaultPage && accessedRoutes.length > 0) {
        const page = {
          path: '/',
          component: Layout,
          redirect: accessedRoutes[0]?.children?.[0]?.path || accessedRoutes[0].path,
          roles: ['admin', 'normal']
        }
        accessedRoutes.unshift(page)
      }
      // 把匹配完有权限的路由给set到vuex里面
      commit('SET_ROUTES', accessedRoutes)
      resolve(accessedRoutes)
    })
  }
}

export default {
  namespaced: true,
  state: stateModal,
  mutations,
  actions
}
