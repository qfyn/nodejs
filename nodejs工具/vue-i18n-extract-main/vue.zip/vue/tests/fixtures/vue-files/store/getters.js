const getters = {
  sidebar: state => state.app.sidebar,
  language: state => state.app.language,
  device: state => state.app.device,
  token: state => state.user.token,
  avatar: state => state.user.avatar,
  name: state => state.user.name,
  userInfo: state => state.user.userInfo,
  permission_routes: state => state.permission.routes,
  systemTitle: state => state.permission.systemTitle,
  organizationTree: state => state.organization.organizationTree,
  selectNodeTree: state => state.organization.selectNodeTree,
  selectNodeData: state => state.organization.selectNodeData,
  departmentList: state => state.organization.departmentList
}
export default getters
