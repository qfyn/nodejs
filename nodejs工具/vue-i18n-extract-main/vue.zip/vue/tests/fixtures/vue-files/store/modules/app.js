import Cookies from 'js-cookie'
import { getLanguage } from '@/lang/index'

const sidebarStatusKey = 'hi-fas-manage-sidebarstatus'
const stateModal = {
  sidebar: {
    opened: Cookies.get(sidebarStatusKey) ? !!+Cookies.get(sidebarStatusKey) : true,
    withoutAnimation: false
  },
  language: getLanguage(),
  device: 'desktop'
}

const mutations = {
  TOGGLE_SIDEBAR: state => {
    state.sidebar.opened = !state.sidebar.opened
    state.sidebar.withoutAnimation = false
    if (state.sidebar.opened) {
      Cookies.set(sidebarStatusKey, 1)
    } else {
      Cookies.set(sidebarStatusKey, 0)
    }
  },
  CLOSE_SIDEBAR: (state, withoutAnimation) => {
    Cookies.set(sidebarStatusKey, 0)
    state.sidebar.opened = false
    state.sidebar.withoutAnimation = withoutAnimation
  },
  TOGGLE_DEVICE: (state, device) => {
    state.device = device
  },
  SET_LANGUAGE: (state, language) => {
    state.language = language
    localStorage.setItem('language', language)
  }
}

const actions = {
  toggleSideBar({ commit }) {
    commit('TOGGLE_SIDEBAR')
  },
  closeSideBar({ commit }, { withoutAnimation }) {
    commit('CLOSE_SIDEBAR', withoutAnimation)
  },
  toggleDevice({ commit }, device) {
    commit('TOGGLE_DEVICE', device)
  },
  setLanguage({ commit }, language) {
    commit('SET_LANGUAGE', language)
  }
}

export default {
  namespaced: true,
  state: stateModal,
  mutations,
  actions
}
