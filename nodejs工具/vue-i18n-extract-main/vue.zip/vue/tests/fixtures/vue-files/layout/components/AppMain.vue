<template>
  <section class="app-main" :class="{'app-main-nothome': this.$route.name === 'Home' }">
    <transition name="fade" mode="out-in">
      <router-view :key="key" />
    </transition>
  </section>
</template>

<script>
export default {
  name: 'AppMain',
  computed: {
    key() {
      return this.$route.path
    }
  }
}
</script>

<style lang="scss" scoped>
.app-main {
  /*50 = navbar  */
  height: calc(100% - #{$navBarHeight});
  width: 100%;
  position: relative;
  overflow: auto;
  background-color: #F0F2F5;
  // transition: all 0.28s;
}
.fixed-header+.app-main {
  padding-top: $navBarHeight;
}

.app-main-nothome{
  height: 100%;
}
.fixed-header+.app-main-nothome {
  padding-top: 0;
}
</style>

<style lang="scss">
// fix css style bug in open el-dialog
.el-popup-parent--hidden {
  .fixed-header {
    padding-right: 15px;
  }
}

.fade-leave-to{
  opacity:0;
  transform: translate3d(0,0,-100px);
  position: absolute;
  z-index: -10;
}
.fade-enter{
  transform: translate3d(0,0,100px);
  position: absolute;
}
.fade-leave-active,.fade-enter-active{
  transition: .5s all ease;
}
</style>
