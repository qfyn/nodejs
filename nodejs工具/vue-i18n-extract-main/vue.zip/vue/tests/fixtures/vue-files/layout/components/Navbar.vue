<template>
  <div class="navbar" :class="{'ishome': this.$route.name === 'Home'}">
    <svg-icon v-show="Object.keys(historyRouteData).includes(this.$route.name)" class="navbar__icon" icon-class="icon_back" @click="handleBack" />
    <breadcrumb v-show="this.$route.name !== 'Home'" class="breadcrumb-container" />
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import Breadcrumb from '@/components/Breadcrumb'

export default {
  components: {
    Breadcrumb
  },
  data() {
    return {
      isShowBack: false,
      historyRouteData: {
        UpdateAuthorization: '/authority/service',
        ActivateService: '/authority/service'
      }
    }
  },
  computed: {
    ...mapGetters([
      'sidebar',
      'historyRoute'
    ])
  },
  mounted() {

  },
  methods: {
    handleBack() {
      this.$router.push(this.historyRouteData[this.$route.name])
    }
  }
}
</script>

<style lang="scss" scoped>
.navbar {
  height: $navBarHeight;
  overflow: hidden;
  position: relative;
  background: #fff;
  z-index: 1003;
  box-shadow: 0 1px 4px rgba(0,21,41,.08);
  transition: height 0.5s ease-in-out;

  .breadcrumb-container {
    float: left;
  }

  &__icon{
    float: left;
    position: relative;
    top: 12px;
    margin-left: 20px;
    cursor: pointer;
    font-size: 16px;
  }
}

.ishome{
  height: 0;
}
</style>
