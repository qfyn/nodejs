export default {
  SecuritySet: 'Security set',
  LimitFailedLogins: 'Limit failed logins',
  LimitFailedLoginsTips: 'Prompt: The number of historical failures will be reset after 24 hours',
  DisableLogonInterval: 'Disable logon interval (minutes)',
  DisableLogonIntervalTips: 'Prompt: When the user fails to log in continuously and reaches the limit, login is prohibited during this time interval',
  PasswordExpirationTime: 'Password expiration time (days)',
  PasswordExpirationTimeTips: 'Prompt: If the user does not update the password during this period, the user password will expire',
  MaximumIdleTimeOfConnection: 'Maximum idle time of connection (minutes)',
  MaximumIdleTimeOfConnectionTips: 'Prompt: If no operation is performed after the configured time, the system will automatically exit',
  PasswordVerificationRules: 'Password verification rules',
  MinimumPasswordLength: 'Minimum password length',
  MustContainEnglish: 'Must contain English letters',
  MustContainNumeric: 'Must contain numeric characters',
  MustContainSpecial: 'Must contain special characters'
}
