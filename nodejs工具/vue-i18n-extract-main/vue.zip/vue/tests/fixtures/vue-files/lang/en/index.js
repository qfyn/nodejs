import Common from 'hi-fas-components/lang/en/Common'
import Page404 from 'hi-fas-components/lang/en/Page404'
import Variable from 'hi-fas-components/lang/en/Variable'
import Validate from 'hi-fas-components/lang/en/Validate'
import Headerbar from 'hi-fas-components/lang/en/Headerbar'
import route from 'hi-fas-components/lang/en/route'

import Account from './Account'
import Organization from './Organization'
import PromptInfo from './PromptInfo'
import authority from './authority'
import System from './System'
import SecuritySet from './SecuritySet'
import Partyapp from './Partyapp'

export default {
  ...Variable,
  route,
  Common,
  Validate,
  Account,

  PromptInfo,

  Headerbar,

  authority,

  System,

  Operation: {
    Save: 'Save',
    Modify: 'Modify',
    Cancel: 'Cancel',
    Confirm: 'Confirm',
    UpdateAuthorization: 'Update Authorization',
    ActivateNow: 'Activate Now',
    Sure: 'Sure',
    EnterSystemHomepage: 'Enter the system homepage'
  },
  SecuritySet,

  Organization,
  Partyapp,
  Page404
}
