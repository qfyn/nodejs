import Common from 'hi-fas-components/lang/zh-CN/Common'
import Page404 from 'hi-fas-components/lang/zh-CN/Page404'
import Variable from 'hi-fas-components/lang/zh-CN/Variable'
import Validate from 'hi-fas-components/lang/zh-CN/Validate'
import Headerbar from 'hi-fas-components/lang/zh-CN/Headerbar'
import route from 'hi-fas-components/lang/zh-CN/route'

import Account from './Account'
import Organization from './Organization'
import PromptInfo from './PromptInfo'
import authority from './authority'
import System from './System'
import SecuritySet from './SecuritySet'
import Partyapp from './Partyapp'

export default {
  ...Variable,
  route,

  Common,
  Validate,

  Account,

  PromptInfo,

  Headerbar,

  authority,

  System,

  Operation: {
    Save: '保存',
    Modify: '修改',
    Cancel: '取消',
    Confirm: '确认',
    UpdateAuthorization: '更新授权',
    ActivateNow: '立即开通',
    Sure: '确定',
    EnterSystemHomepage: '进入系统主页'
  },
  SecuritySet,

  Organization,
  Partyapp,
  Page404
}
