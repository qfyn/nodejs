export default {
  SecuritySet: '安全设置',
  LimitFailedLogins: '限制失败登录次数',
  LimitFailedLoginsTips: '提示：24小时后会重置历史失败次数',
  DisableLogonInterval: '禁止登录时间间隔(分钟)',
  DisableLogonIntervalTips: '提示：当用户连续登录失败达到限制后，那么在此时间间隔内禁止登录',
  PasswordExpirationTime: '密码过期时间(天)',
  PasswordExpirationTimeTips: '提示：如果用户在此期间没有更新密码，用户密码将过期失效',
  MaximumIdleTimeOfConnection: '连接最大空闲时间(分钟)',
  MaximumIdleTimeOfConnectionTips: '提示：如果超过该配置时间没有操作，系统将自动退出',
  PasswordVerificationRules: '密码校验规则',
  MinimumPasswordLength: '密码最小长度',
  MustContainEnglish: '必须包含英文字母',
  MustContainNumeric: '必须包含数字字符',
  MustContainSpecial: '必须包含特殊字符'
}
