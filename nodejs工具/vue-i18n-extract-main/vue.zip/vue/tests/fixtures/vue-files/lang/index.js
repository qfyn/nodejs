import Vue from 'vue'
import VueI18n from 'vue-i18n'
import elementEnLocale from 'ElementUI/locale/lang/en' // element-ui 英文
import elementZhLocale from 'ElementUI/locale/lang/zh-CN'// element-ui 简体中文
import enLocale from './en/index'
import zhLocale from './zh-CN/index'
// import ElementLocale from 'ElementUI/locale'

Vue.use(VueI18n)

const messages = {
  en: {
    ...enLocale,
    ...elementEnLocale
  },
  'zh-Hans': { // 简体中文
    ...zhLocale,
    ...elementZhLocale
  }
}

export const languageList = [
  {
    name: '中文(简体)',
    value: 'zh-Hans'
  },
  {
    name: 'English',
    value: 'en'
  }
]

export function getLanguage() {
  const chooseLanguage = localStorage.getItem('language')
  if (chooseLanguage) return chooseLanguage

  // if has not choose language
  const language = (navigator.language || navigator.browserLanguage).toLowerCase()
  const locales = Object.keys(messages)
  for (const locale of locales) {
    if (language.indexOf(locale) > -1) {
      return locale
    }
  }
  return 'zh-Hans' // 默认语言：简体中文
}

const i18n = new VueI18n({
  // set locale
  // options: en | zh | es
  locale: getLanguage(),
  // set locale messages
  messages
})

// ElementLocale.i18n((key, value) => i18n.t(key, value))

export default i18n
