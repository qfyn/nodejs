export default {
  UserName: 'User Name',
  Remarks: 'Remarks',
  PleaseSelectOneUser: 'Please select at least one user',
  DeleteConfirm: 'It cannot be recovered after deletion. Do you want to permanently delete the user',
  AuthorizationModule: 'Authorization Module',
  UpperLimitOfSitesAccess: 'Upper limit of sites access',
  UpperLimitOfAccess: 'Upper limit of access',
  UpperLimitOfTerminalAccess: 'Upper limit of terminal access',
  InputUpperLimitOfTerminalAccess: 'Please enter the upper limit of terminal access',
  InputUpperLimitOfSitesAccess: 'Please enter the upper limit of sites access'
}
