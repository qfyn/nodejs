export default {
  IdentificationCode: '标识码',
  AuthorizedUser: '授权用户',
  RegistrationCode: '注册码',
  Registration: '注册',
  BusinessLicense: '企业税号',
  GenerateIdentificationCode: '生成标识码',
  DssTips:
    '请您点击生成标识码按钮，把生成的标识码发送给系统管理员获取注册码，输入注册码完成服务注册',
  ModifyBasicInformation: '修改基本信息',
  OpeningDss: '恭喜您开通差分服务系统',
  OpeningPlatform: '恭喜您开通运维管理系统',
  OpeningOmc: '恭喜您开通运行监测系统',
  StreamsAndTerminalCountsTips:
    '数据流可接入 {streamCount} 条，终端用户账号可接入 {terminalCount} 个'
}
