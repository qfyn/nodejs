export default {
  UserName: '用户名称',
  Remarks: '备注',
  PleaseSelectOneUser: '请至少选择一个用户',
  DeleteConfirm: '删除后不可恢复，是否永久删除用户',
  AuthorizationModule: '授权模块',
  UpperLimitOfAccess: '接入上限'
}
