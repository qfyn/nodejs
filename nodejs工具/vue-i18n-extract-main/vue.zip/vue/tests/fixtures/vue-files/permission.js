import router from './router'
import store from './store'
import NProgress from 'nprogress' // progress bar
import 'nprogress/nprogress.css' // progress bar style
import { getToken } from 'hi-fas-utils/src/token' // get token from cookie
import getPageTitle from '@/utils/get-page-title'
import { loginPageUrl } from '@/settings'
import { getLoginInfo, handleUserChange, _debounce } from 'hi-fas-utils/src/permission'
// import { getRouteByRole } from '@/router/asyncRoute'
import { keepAliveHandle } from 'hi-fas-utils/src/security'

let routesData = []
const debounce = _debounce()

NProgress.configure({ showSpinner: false }) // NProgress Configuration

const toLogin = (reset) => {
  const url = reset ? loginPageUrl + '&reset=reset123' : loginPageUrl
  window.open(url, '_self')
}

router.beforeEach(async(to, from, next) => {
  NProgress.start()
  document.title = getPageTitle(to)
  const hasToken = getToken()
  if (hasToken) {
    handleUserChange(hasToken)
    const hasGetUserInfo = store.getters.name
    if (hasGetUserInfo) {
      debounce(store.getters.routes, to.path)
      next()
    } else {
      try {
        routesData = []
        await store.dispatch('user/getInfo', { id: getLoginInfo().userId }).then(res => {
          routesData = res.resources.find(item => item.path === '/manage')
          store.commit('permission/SET_SYSTEMTITLE', routesData?.name)
        })

        // routesData.children = []
        if (!routesData?.children?.length) {
          await store.dispatch('user/resetToken')
          toLogin('reset')
          return
        }

        // 根据用户角色筛选菜单
        // const accessRoutes = getRouteByRole(role)
        const accessRoutes = await store.dispatch('permission/generateRoutes', routesData?.children || [])
        router.addRoutes(accessRoutes)

        keepAliveHandle() // 无操作自动退出

        next({ ...to, replace: true })
      } catch (error) {
        await store.dispatch('user/resetToken')
        // Message.error(error || 'Has Error')
        toLogin()
        NProgress.done()
      }
    }
  } else {
    await store.dispatch('user/resetToken')
    toLogin()
    NProgress.done()
  }
})

router.afterEach(() => {
  // finish progress bar
  NProgress.done()
})
