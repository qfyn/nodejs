import i18n from '@/lang'
export {
  isExternal,
  validateStationID,
  validateIdentifier,
  validateGroupName,
  validateSpecial,
  validateSpecialNull,
  validatePsw,
  validateB,
  validateLat,
  validateL,
  validateLng,
  validateH,
  validateIp,
  validatePort,
  validateUserName,
  isvalidUsername,
  MatchChineseLetterUnderLineAndNum,
  IsNumberWord,
  MatchPhoneNum,
  MatchChineseLetter,
  trimExp,
  IsSixToTwlNumber,
  IsSixToTwtNumber,
  IsTwFourlNumber,
  validateZero,
  validateAntennaheight,
  validateNumber,
  validatePhone,
  validatePhone_norequired,
  validateEmail,
  validateEmail_norequired,
  validatePartitionName,
  validateInterval,
  validateIsNumber,
  validateIsNumber_positive,
  checkVersion,
  checkNameSpaces,
  validateMenuName,
  validatePath,
  checkLicense
} from 'hi-fas-utils/src/validate'
/**
 * 校验函数
 */

/**
 * 验证密码，6-12字母数字组合
 * @param {*} rule
 * @param {*} value
 * @param {*} callback
 */
// export function validatePassword(rule, value, callback) {
//   var reg = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,12}$/
//   var text = value || '请输入6-12个字母、数字'
//   if (!reg.test(value)) {
//     callback(new Error(text))
//   } else {
//     callback()
//   }
// }

// 用户名验证
// export function validateUserName(rule, value, callback) {
//   var nameReg = /[\u4e00-\u9fa5]+/g
//   var specialReg = /[`~!@#$%^&*()+<>?:"{},\/;\'[\]·！#￥（——）：；“”‘、，|《。》？、【】[\]]/im
//   if (nameReg.test(value)) {
//     callback(new Error('不能存在中文'))
//   } else if (specialReg.test(value)) {
//     callback(new Error(i18n.t('Validate.Special')))
//   } else {
//     callback()
//   }
// }

// 验证座机或手机号码
export function validateTelephone(rule, value, callback) {
  var reg = /^(((0\d{2,3}-)?\d{7,8})|(1(3[0-9]|4[01456879]|5[0-35-9]|6[2567]|7[0-8]|8[0-9]|9[0-35-9])\d{8}))$/
  if (value && !reg.test(value)) {
    callback(new Error(i18n.t('PromptInfo.PleaseInputTheCorrectTelephone')))
  } else {
    callback()
  }
}

// 验证传真号码
export function validateFax(rule, value, callback) {
  var reg = /^(?:\d{3,4}-)?\d{7,8}(?:-\d{1,6})?$/
  if (value && !reg.test(value)) {
    callback(new Error(i18n.t('PromptInfo.PleaseInputTheCorrectFaxNumber')))
  } else {
    callback()
  }
}
