/**
 * 公共函数
 */

export { getQueryVariable, delUrlParam } from 'hi-fas-utils/src/url'
export { getLocalStorage, setLocalStorage, updateLocalStorage } from 'hi-fas-utils/src/localStorage'
export { dateFormat } from 'hi-fas-utils/src/time'
export { uuid } from 'hi-fas-utils/src/random'
