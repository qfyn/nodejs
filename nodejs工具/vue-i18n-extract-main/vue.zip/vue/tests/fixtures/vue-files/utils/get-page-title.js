export { default } from 'hi-fas-utils/src/get-page-title'
