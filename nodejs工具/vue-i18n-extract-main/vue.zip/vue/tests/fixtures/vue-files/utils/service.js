import Vue from 'vue'
import JSEncrypt from 'jsencrypt'

/**
 * RSA非对称加密
 * @param {*} data 需要加密的数据
 */
Vue.prototype.$rsaEncrypt = function(data) {
  const PUBLIC_KEY = `
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAp16nMFzVfPa1Bn2KrSfZ
m3LABC9D+fvpuHjKiddyShDtORQ/q20Rgnjjb4ImDNWsJvznbSaO+vHNzLpmuYPi
+0ztv+6g4R07Mdq5rPw6zsFwxb82mo51QfH09/2JyseGktozL/24TlOcu3l+JaTo
8wRzzuT6LguKrB/KhFoOOX49x6gQZ+1xnLtaJGgMQap8krVF2jorAfJPrCggKEEt
jVtHXuzMHAAi0Xp8oinHLBq2s+AFh0g1DD2mQd3/AkwHryaRH9W7gzUBQ0SVEINO
JLFeW3aUOVj/7w8Rkbbqu8Fcmqtsw5kEUGgA087lca1JfsDikksyqDFjElTQzkN9
AwIDAQAB
`
  // new一个对象
  const encrypt = new JSEncrypt()
  // 设置公钥
  encrypt.setPublicKey(PUBLIC_KEY)
  // password是要加密的数据,此处不用注意+号,因为rsa自己本身已经base64转码了,不存在+,全部是二进制数据
  const result = encrypt.encrypt(data)
  return result
}

Vue.prototype.$rsaDecrypt = function(password) {
  const privateKey = '---'
  const decrypt = new JSEncrypt()
  decrypt.setPrivateKey(privateKey)
  const result = decrypt.decrypt(password)
  return result
}
