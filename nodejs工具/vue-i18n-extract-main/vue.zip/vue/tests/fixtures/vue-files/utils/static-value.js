// 一些全局常量配置
import i18n from '@/lang'
/**
 * 固件类型
 */
export function roleTypeOptions() {
  return [
    {
      value: 0,
      label: i18n.t('authority.Administrators')
    },
    {
      value: 1,
      label: i18n.t('authority.AdvancedUser')
    },
    {
      value: 2,
      label: i18n.t('authority.OrdinaryUsers')
    }
  ]
}
