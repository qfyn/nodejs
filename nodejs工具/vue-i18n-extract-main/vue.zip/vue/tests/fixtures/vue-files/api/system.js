// 服务注册
import request from '@/utils/request'
/**
 *
生成标识码
 */
export function PostIdentifyNum(data) {
  return request({
    url: '/system/register/identifyNum',
    method: 'post',
    data: data
  })
}

/**
 *
激活注册
 */
export function RegisterActivate(data) {
  return request({
    url: '/system/register/activate',
    method: 'post',
    data: data
  })
}

/**
 *
获取注册信息
 */
export function RegisterInfo(data) {
  return request({
    url: '/system/register/info',
    method: 'get'
  })
}

/**
 *
获取当前终端用户数和基站数
 */
export function RegisterCurrentNum(data) {
  return request({
    url: '/terminal/register/occupyResourcesCount',
    method: 'get'
  })
}

// 基本信息
export function UpdateRegisterInfo(data) {
  return request({
    url: '/system/register/updateRegister',
    method: 'post',
    data
  })
}
