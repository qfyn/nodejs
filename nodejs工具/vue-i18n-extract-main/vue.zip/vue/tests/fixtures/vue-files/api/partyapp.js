import http from '@/utils/http'

// 用户列表
export function GetUserList(data) {
  return http.get('/system/openAccount/paged', data)
}

// 删除
export function BatchDelete(data) {
  return http.delete('/system/openAccount/delete/batch', data)
}

// 新增
export function AddUser(data) {
  return http.post('/system/openAccount/add', data)
}

// 编辑
export function UpdateUser(data) {
  return http.post('/system/openAccount/update', data)
}

// 检查用户名是否重复
export function CheckUser(data) {
  return http.get('/system/openAccount/check', data)
}

// 授权模块
export function GetModuleOptions(data) {
  return http.get('/system/openAccount/get/apps', data)
}
