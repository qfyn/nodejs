import http from '@/utils/http'

export { Logout as logout, LookAccount as getInfo } from 'hi-fas-utils/src/api/user'

// 查询国家
export function GetCountry() {
  return http.get('/system/country/listAll')
}

// 查询省份
export function GetProvince(data) {
  return http.get('/system/province/listAll', data)
}

// 查询城市
export function GetCity(data) {
  return http.get('/system/city/listAll', data)
}

// 修改联系信息
export function UpdateContactinfo(data) {
  return http.post('/system/admin/user/contactinfo/update', data)
}

// 修改密码
export function Updatepassword(data) {
  return http.post('/system/admin/user/updatepassword', data)
}

// 验证邮箱唯一
export function CheckEmail(data) {
  return http.get('/system/admin/user/checkemail', data)
}

// 修改手机号
export function UpdateTelephone(data) {
  return http.post('/system/admin/user/updatetelephone', data)
}

// 修改邮箱
export function UpdateEmail(data) {
  return http.post('/system/admin/user/updateemail', data)
}
