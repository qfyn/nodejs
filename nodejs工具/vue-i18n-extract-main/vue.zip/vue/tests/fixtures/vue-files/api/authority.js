import http from '@/utils/http'

// 新增资源
export function AddResource(data) {
  return http.post('/system/resourceManage/add', data)
}

// 资源树状列表
export function GetResourceList(data) {
  return http.get('/system/resourceManage/list', data)
}

// 资源树状列表
export function DeleteResource(data) {
  return http.post('/system/resourceManage/delete', data)
}

// 查询资源详情
export function GetResourceRetails(data) {
  return http.get('/system/resourceManage/select', data)
}

// 更新资源
export function UpdateResource(data) {
  return http.post('/system/resourceManage/update', data)
}

// 查看资源名是否重复
export function CheckRepeatName(data) {
  return http.get('/system/resourceManage/name/repeat', data)
}

// 查看路径是否重复
export function CheckRepeatPath(data) {
  return http.get('/system/resourceManage/path/repeat', data)
}

// 排序
export function SortResource(data) {
  return http.post('/system/resourceManage/sort/update', data)
}

// 角色-分页列表
export function GetRoleList(data) {
  return http.get('/system/roleManage/role/paged', data)
}

// 角色-删除
export function DeleteRole(data) {
  return http.delete('/system/roleManage/role/delete', data)
}

// 角色-批量删除
export function BatchDeleteRole(data) {
  return http.delete('/system/roleManage/role/delete/batch', data)
}

// 角色-新增
export function AddRole(data) {
  return http.post('/system/roleManage/role/add', data)
}

// 角色-修改
export function UpdateRole(data) {
  return http.post('/system/roleManage/role/update', data)
}

// 角色-查询
export function GetRoleDetails(data) {
  return http.get('/system/roleManage/role/get', data)
}

// 角色-查询
export function CheckRoleName(data) {
  return http.get('/system/roleManage/role/check', data)
}

