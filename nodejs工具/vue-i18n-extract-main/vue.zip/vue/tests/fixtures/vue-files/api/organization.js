import http from '@/utils/http'

// const pxy = ''
// 组织部门树
export function queryOrgTree(data) {
  return http.get('/system/dept/get/deptTree', data)
}

// 部门-新增
export function CreateDept(data) {
  return http.post('/system/dept/create', data)
}

// 部门-新增成员-查询所有角色
export function GetRoles(data) {
  return http.get('/system/roleManage/role/list', data)
}

// 删除部门信息
export function DeleteDept(data) {
  return http.delete('/system/dept/delete', data)
}

// 查询部门信息
export function GetDeptDetails(data) {
  return http.get('/system/dept/get', data)
}

// 修改部门信息
export function UpdateDept(data) {
  return http.post('/system/dept/update', data)
}

// 移入/移出部门成员
export function MoveDeptUser(data) {
  return http.post('/system/dept/user/move', data)
}

// 根据部门分页查询部门成员
export function GetDeptUserLIst(data) {
  return http.get('/system/dept/user/paged', data)
}

// 校验部门名称重复
export function CheckDeptName(data) {
  return http.get('/system/dept/check', data)
}

// ---------------------------------------------------

// 新增成员
export function CreateUser(data) {
  return http.post('/system/admin/user/create', data)
}

// 检查账号名是否重复
export function CheckAccountName(data) {
  return http.get('/system/admin/user/checkname', data)
}

// 账号列表
export function GetUserList(data) {
  return http.get('/system/admin/user/list', data)
}
// 重置密码
export function ResetPassword(data, id) {
  return http.post('/system/admin/user/resetpassword?userId=' + id, data)
}

// 检查邮箱是否重复
export function CheckAccountEmail(data) {
  return http.get('/system/admin/user/checkemail', data)
}

// 删除
export function DeleteUser(data) {
  return http.post('/system/admin/user/delete', data)
}

// 编辑账号
export function EditAccount(data) {
  return http.post('/system/admin/user/editaccount', data)
}

// 获取重置后的密码
export function GetResetPassword(data) {
  return http.get('/system/admin/user/resetpassword/note', data)
}

