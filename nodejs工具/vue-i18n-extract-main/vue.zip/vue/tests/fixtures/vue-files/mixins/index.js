import { debounce } from 'lodash-es'
import MyTable from '@/components/Table'
import Pagination from '@/components/Pagination/index'
import i18n from '@/lang'
import { mapGetters } from 'vuex'

/**
 * echarts自适应
 */
export const resizeChart = {
  data() {
    return {
      $_sidebarElm: null
    }
  },
  computed: {
    ...mapGetters(['language'])
  },
  watch: {
    language() {
      this.initChart()
    }
  },
  mounted() {
    // 函数消抖
    this.__resizeHandler = debounce(() => {
      if (this.chartInstance) {
        if (this.chartHeight && this.doResize) {
          this.doResize && this.doResize()
        } else {
          this.chartInstance.resize()
        }
      } else {
        this.doResize && this.doResize()
      }
    }, 100)
    window.addEventListener('resize', this.__resizeHandler)

    this.$_sidebarElm = document.getElementsByClassName('sidebar-container')[0]
    this.$_sidebarElm && this.$_sidebarElm.addEventListener('transitionend', this.$_sidebarResizeHandler)
  },
  activated() {
    this.chartInstance && this.chartInstance.resize()
    this.doResize && this.doResize()
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.__resizeHandler)

    this.$_sidebarElm && this.$_sidebarElm.removeEventListener('transitionend', this.$_sidebarResizeHandler)
  },
  methods: {
    // use $_ for mixins properties
    // https://vuejs.org/v2/style-guide/index.html#Private-property-names-essential
    $_sidebarResizeHandler(e) {
      if (e.propertyName === 'width') {
        this.__resizeHandler()
      }
    }
  }
}

/**
 * 列表页表格
 */
export const multipleTable = {
  components: {
    Pagination,
    MyTable
  },
  data() {
    return {
      multipleSelection: [],
      listLoading: false,
      deleteLoading: false,
      tableData: [],
      currentId: 0,
      isEdit: false,
      listQuery: {
        page: 1,
        limit: 20
      },
      total: 0,
      dialogVisible: false,
      btn_disabled: true,
      btn_type: 'info',
      btn_plain: true
    }
  },
  methods: {
    handleCreate() {
      this.currentId = 0
      this.isEdit = true
      this.dialogVisible = true
    },
    // 批量删除
    handleDelete(row) {
      const deleteCount = row.id ? 1 : this.multipleSelection.length
      if (deleteCount) {
        this.$confirm(i18n.t('PromptInfo.batchDelete', { deleteCount: deleteCount }), i18n.t('PromptInfo.Tips'), {
          type: 'warning'
        }).then(async() => {
          const deleteList = row.id ? [row] : this.multipleSelection
          if (!row.id) this.deleteLoading = true
          await this.multipleDelete(deleteList).catch(() => {})
          this.deleteLoading = false
        })
      } else {
        this.$message.closeAll()
        this.$message(i18n.t('PromptInfo.PleaseSelectData'))
      }
    },
    handleSearch() {
      this.listQuery.page = 1
      this.fetchList()
    },
    handleLook({ id }) {
      this.currentId = id
      this.isEdit = false
      this.dialogVisible = true
    },
    handleEdit({ id }) {
      this.currentId = id
      this.isEdit = true
      this.dialogVisible = true
    },
    onConfirm(isSuccess) {
      this.dialogVisible = false
      isSuccess && this.fetchList()
    },
    /**
     * 重新刷新当前分页
     * @summary 处理删除分页最后一页的所有数据时，PageIndex不变，页面列表为空的问题
     * @param {Number [int]} listCount 列表改变的个数（暂为删除操作）
     */
    refreshCurrentPage(listCount) {
      this.total -= listCount
      const { page, limit } = this.listQuery
      if (this.total > 0 && (page - 1) * limit === this.total) {
        this.listQuery.page -= 1
      }
      this.fetchList()
    },
    changeBtnType(data) {
      this.btn_disabled = !data
      this.btn_type = data ? 'primary' : 'info'
      this.btn_plain = !data
    },
    // 刷新表格时--如果有选择数据，应该保留
    toggleRowSelection(data) {
      // 如果是自动刷新的表格，则保留多选的结果，否则清空多选
      if (!(data && data.noClear)) this.$refs.table.clearSelection()
      if (this.multipleSelection.length > 0) {
        const historySelection = JSON.parse(JSON.stringify(this.multipleSelection)) || []
        this.toggleRowSelection(historySelection)
        this.$nextTick(() => {
          historySelection.forEach(item => {
            const row = this.tableData.find(ele => ele.id === item.id)
            if (row) {
              this.$refs.table.toggleRowSelection(row)
            }
          })
        })
      }
    }
  }
}

/**
 * 判断是否执行activated
 */
export const loadData = {
  data() {
    return {
      firstLoad: false,
      updateDataFn: null
    }
  },
  mounted() {
    this.firstLoad = true
    this.loadMounted()
  },
  activated() {
    if (this.firstLoad) {
      this.firstLoad = false
      return
    }
    this.loadActivated()
  },
  deactivated() {
    this.updateDataFn && this.updateDataFn.stop() // 停止定时器
    this.updateDataFn = null
  },
  beforeDestroy() {
    this.updateDataFn && this.updateDataFn.stop() // 停止定时器
    this.updateDataFn = null
  },
  methods: {
    loadMounted() {},
    loadActivated() {}
  }
}

