export { paginationTable } from 'hi-fas-components/base/zPage/pagination'
