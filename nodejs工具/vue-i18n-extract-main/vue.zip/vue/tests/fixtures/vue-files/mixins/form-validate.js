/**
 * 表单校验操作
 */
export const formValidate = {
  methods: {
    /**
     * 校验
     * @param {*} formName
     * @returns
     */
    submitForm(formName) {
      return new Promise((resolve, reject) => {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            resolve(true)
          } else {
            resolve(false)
            return false
          }
        })
      })
    },
    /**
     * 重置表单校验
     * @param {*} formName
     */
    resetForm(formName) {
      this.$refs[formName].resetFields()
    }
  }

}
