/* Layout */
import Layout from '@/layout'

export const asyncRoute = [
  // {
  //   path: '/',
  //   component: Layout,
  //   redirect: '/organization',
  //   roles: ['admin']
  // },
  // {
  //   path: '/',
  //   component: Layout,
  //   redirect: '/accountcenter',
  //   roles: ['normal']
  // },
  {
    path: '/accountcenter',
    component: Layout,
    redirect: '/accountcenter/accountinfo',
    meta: { title: 'AccountManage', icon: 'accountcenter' },
    roles: ['admin', 'normal'],
    children: [
      {
        path: '/accountcenter/accountinfo',
        name: 'accountinfo',
        component: () => import('@/views/accountcenter/accountinfo/index'),
        meta: { title: 'AccountInfo', icon: '点' },
        roles: ['admin', 'normal']
      },
      {
        path: '/system/accountset',
        name: 'accountset',
        component: () => import('@/views/accountcenter/accountset/index'),
        meta: { title: 'Accountset', icon: '点' },
        roles: ['admin']
      },
      {
        path: '/accountcenter/securityset',
        name: 'securityset',
        component: () => import('@/views/accountcenter/securityset/index'),
        meta: { title: 'SecuritySet', icon: '点' },
        roles: ['admin', 'normal']
      }
    ]
  },
  {
    path: '/organization',
    // name: 'organization',
    component: Layout,
    alwaysShow: true,
    redirect: '/organization/memberlist',
    meta: { title: 'Organization', icon: 'tree' },
    roles: ['admin'],
    children: [
      {
        path: '/organization/structure',
        name: 'structure',
        component: () => import('@/views/organization/structure/index'),
        meta: { title: 'Organization', icon: '点' },
        roles: ['admin']
      },
      {
        path: '/organization/memberlist',
        name: 'memberlist',
        component: () => import('@/views/organization/memberlist/index'),
        meta: { title: 'MemberList', icon: '点' },
        roles: ['admin']
      }
    ]
  },
  {
    path: '/authority',
    component: Layout,
    redirect: '/authority/rolemanage',
    meta: { title: 'AuthorityManage', icon: 'authoritymanage' },
    roles: ['admin'],
    children: [
      {
        path: '/authority/appmanage',
        name: 'appmanage',
        component: () => import('@/views/authority/appmanage/index'),
        meta: { title: 'AppManage', icon: '点' },
        roles: ['admin']
      },
      {
        path: '/authority/rolemanage',
        name: 'rolemanage',
        component: () => import('@/views/authority/rolemanage/index'),
        meta: { title: 'RoleManage', icon: '点' },
        roles: ['admin']
      },
      {
        path: '/authority/service',
        name: 'ServiceAuthorization', // 服务注册
        component: () => import('@/views/authority/service/index'),
        meta: { title: 'ServiceAuthorization', roles: ['admin'] },
        children: [
          {
            path: '/authority/service/update-auth',
            name: 'UpdateAuthorization', // 更新授权
            component: () => import('@/views/authority/service/update-auth/index'),
            hidden: true,
            meta: { title: 'UpdateAuthorization', activeMenu: '/authority/service', roles: ['admin'] }
          },
          {
            path: '/authority/service/activate-service',
            name: 'ActivateService', // 开通服务
            component: () => import('@/views/authority/service/update-auth/index'),
            hidden: true,
            meta: { title: 'ActivateService', activeMenu: '/authority/service', roles: ['admin'] }
          }
        ]
      }
    ]
  },
  {
    path: '/partyapp',
    component: Layout,
    hidden: false,
    redirect: '/partyapp/applist',
    meta: { title: 'PartyAppManage', icon: 'authoritymanage' },
    roles: ['admin'],
    children: [
      {
        path: '/partyapp/applist',
        name: 'partyapp',
        component: () => import('@/views/partyapp/applist/index'),
        meta: { title: 'AppList', icon: '点' },
        roles: ['admin']
      }
    ]
  }
]
