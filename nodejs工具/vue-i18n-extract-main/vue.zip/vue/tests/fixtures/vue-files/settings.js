const sys = require('hi-fas-components/system')
module.exports = {

  title: sys.hifas.zh,

  /**
   * @type {boolean} true | false
   * @description Whether fix the header
   */
  fixedHeader: false,

  /**
   * 登录界面URL
   */
  loginPageUrl: '/login/#/?subname=manage'
}
