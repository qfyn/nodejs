<template>
  <el-select
    v-model="selectId"
    class="form-item "
    popper-class="departmentselect"
    :placeholder="$t('Organization.PleaseSelectDepartment')"
    @change="handleChange"
  >
    <el-option
      v-for="item in departmentOptions"
      :key="item.id"
      :label="item.deptSimpleName"
      :value="item.id"
      :title="item.deptSimpleName + item.orgName"
    >
      <span>{{ item.deptSimpleName }}</span>
      <span style="color: #c0c4cc">{{ item.orgName }}</span>
    </el-option>
  </el-select>
</template>

<script>
export default {
  name: 'PooDepartment',
  props: {
    departmentOptions: {
      type: Array,
      default: () => {
        return []
      }
    },
    departmentId: {
      type: Number,
      default: null
    }
  },
  data() {
    return {
      selectId: null
    }
  },
  watch: {
    departmentId() {
      this.selectId = JSON.parse(JSON.stringify(this.departmentId))
    }
  },
  created() {
    this.selectId = JSON.parse(JSON.stringify(this.departmentId))
  },
  methods: {
    handleChange(val) {
      this.$emit('update:departmentId', val)
      this.$emit('handleChange', val)
    }
  }
}
</script>
