import Vue from 'vue'

import 'normalize.css/normalize.css' // A modern alternative to CSS resets

import i18n from '@/lang'

import '@/styles/index.scss' // global css

import ElementUI from 'ElementUI'
import { Message } from 'hi-fas-utils/src/overwrite'

import App from './App'
import store from './store'
import router from './router'

import '@/icons' // icon
import 'hi-fas-components/icons' // icon
import '@/permission' // permission control
import * as Service from '@/utils/service'
import { windowResizeHandle } from 'hi-fas-utils/src/devicePixelRatio'

Vue.config.productionTip = false

Vue.use(ElementUI, { size: 'small', i18n: (key, value) => i18n.t(key, value) }, Service)
Vue.prototype.$message = Message

// 定义全局变量
import * as validate from '@/utils/validate'
import * as api from '@/api/index'
import * as config from '@/utils/static-value'
global.tools = {
  validate,
  api,
  config
}

// 引入全局组件
import 'hi-fas-components/registerGlobeComponents'

new Vue({
  el: '#app',
  router,
  store,
  i18n,
  render: h => h(App)
})
windowResizeHandle()

// 页面激活校验权限
import { getToken } from 'hi-fas-utils/src/token' // get token from cookie
import { windowActiveHandle } from 'hi-fas-utils/src/permission'
windowActiveHandle(getToken)
